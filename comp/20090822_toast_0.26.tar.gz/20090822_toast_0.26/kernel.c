#include "stuff.h"
#include "datastr.c"
#include "gui/monitor.c"
#include "keybd/keyboard.c"
#include "init/paging.c"
//#include "init/kheap.c"
#include "debug.c"
#include "kheap.c"
//#include "vfs/vfs.c"
#include "initrd/initrd.c"
#include "net/rtl8029.c"
#include "pci/pci.c"
//#include "tasking/tasking.c"

void page_fault(registers_t regs)
{
  prints("PAGE FAULT: ");
  u32 faulting_address;
  asm volatile("mov %%cr2, %0" : "=r" (faulting_address));
  prints("at 0x");
  print_hex_32(faulting_address);
  prints(" with error code ");
  print_bin_32(regs.err_code);
  prints("\n");
}

void isr_handler(registers_t regs)
{
  if(regs.int_no == 0xE)
    page_fault(regs);
  else if(regs.int_no == 0x21)
    keyboard_handler();
}

void init()
{
  //paging_init();
  prints("HELLO PAGED WORLD!");
  //heap_init();
  //rd_init();
  //tasking_init();
  //pci_init();
}

void kmain(u32 vidstart)
{
  monitor_init((pixel_t *)vidstart);
  u32 espv;
  asm volatile("mov %%esp, %0": "=r"(espv));
  prints("esp: ");print_hex_32(espv);prints("\n");
  prints("vidstart: ");print_hex_32(vidstart);prints("\n");
  init();
}
