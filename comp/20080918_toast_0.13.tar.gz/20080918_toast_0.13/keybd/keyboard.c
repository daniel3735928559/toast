#include "scancodes.h"

void keyboard_handler()
{
	u8 sc = inb(0x60);
	if(sc)
	{
		if(sc & (0x80))
		{

		}
		else
		{
			s8 input = scancodes[sc];
			if(input > 0)
				putch(input);
		}
	}
	outb(0x20, 0x20);
}
