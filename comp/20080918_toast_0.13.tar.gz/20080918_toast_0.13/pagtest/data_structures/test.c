#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../stuff.h"
#include "util.c"
#include "stack.c"
#include "bitmap.c"
#include "imap.c"
#include "bin_tree.c"

int main(char argc, char **argv)
{
	/*
	u32 x = 87;
	bit_print(x);
	bit_print(x & -x);
	printf("%d\n",get_first_set(x));
	printf("%d\n",get_first_set_alt(x));
	//*/
	
	//*
	bitmap_t *b = bitmap_create(320);
	bitmap_print(b);
	printf("hi\n");
	u32 i;
	//*/
	//*
	for(i = 0; i < 320; i++)
	{
		bitmap_set(b, i);
	}
	bitmap_print(b);
	printf("hio\n");
	bitmap_clear(b, 3);
	bitmap_clear(b, 7);
	bitmap_clear(b, 10);
	bitmap_clear(b, 11);
	bitmap_clear(b, 12);
	bitmap_clear(b, 13);
	bitmap_clear(b, 14);
	bitmap_clear(b, 33);
	bitmap_clear(b, 73);
	bitmap_print(b);
	printf("hiohi\n");
	bit_print(bitmap_get_context(b, 3));
	bit_print(bitmap_get_context(b, 7));
	bit_print(bitmap_get_context(b, 33));
	bit_print(bitmap_get_context(b, 73));
	printf("%d-%d-%d-%d\n",	 	~bitmap_get_context(b, 3), 
										~bitmap_get_context(b, 7), 
										~bitmap_get_context(b, 33), 
										~bitmap_get_context(b, 73));
	//*/

	/*stack_t *s = stack_create(100);\
	printf("%d,%d\n", s->top, s->base);
	printf("push: %d\n", stack_push(s, 10));
	printf("push: %d\n", stack_push(s, 20));
	printf("pop: %d\n", stack_pop(s));
	printf("pop: %d\n", stack_pop(s));*/
	//*
	imap_t *imap = imap_create(64);
	for(i = 0; i < 80; i++)
	{
		printf("%d:%d:%d\n\n", i, imap_set_next(imap), stack_peek(imap->stack));
		bitmap_print(imap->bitmap);
	}
	printf("%d\n", imap_set_next(imap));
	for(i = 50; i < 100; i++)
	{
		printf("CLEAR %d\n", i);
		imap_clear(imap, i);
		bitmap_print(imap->bitmap);
	}
	imap_clear(imap, 6);
	imap_clear(imap, 9);
	for(i = 0; i < 80; i++)
	{
		printf("%d:%d:%d\n\n", i, imap_set_next(imap), stack_peek(imap->stack));
		bitmap_print(imap->bitmap);
	}
	//*/

	/*
	bit_print(134929);
	stack_t *s = stack_create(64);
	for(i = 0; i < 64; i++)
	{
		stack_push(s, i);
		printf("%d\n", stack_peek(s));
		stack_print(s);
	}
	stack_print(s);
	//*/
	/*
	bin_tree_t *tree = bin_tree_create(100, 23);
	bin_tree_print(tree);
	bin_tree_insert(tree, 25);
	bin_tree_print(tree);
	bin_tree_insert(tree, 2);
	bin_tree_print(tree);
	bin_tree_insert(tree, 11);
	bin_tree_print(tree);
	bin_tree_insert(tree, 13);
	bin_tree_print(tree);
	bin_tree_insert(tree, 31);
	bin_tree_print(tree);
	bin_tree_insert(tree, 3);
	bin_tree_print(tree);
	bin_tree_insert(tree, 10);
	bin_tree_print(tree);
	bin_tree_insert(tree, 19);
	bin_tree_print(tree);
	bin_tree_rotate(tree, tree->root, 1);
	bin_tree_print(tree);
	//*/
	printf("Done\n");
	
}
