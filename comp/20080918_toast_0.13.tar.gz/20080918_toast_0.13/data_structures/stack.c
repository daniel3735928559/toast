typedef struct
{
	u32 max;
	u32 *base;
	u32 *top;
} stack_t;

int stack_push(stack_t *s, u32 x)
{
	if(s->top - s->base >= s->max)
	{
		return 1;
	}
	*(++s->top) = x;
	return 0;
}
u32 stack_pop(stack_t *s)
{
	if(s->top == s->base)
	{
		return;
	}
	s->top -= 1;
	u32 x = *(s->top);
	return x;
}
u32 stack_peek(stack_t *s)
{
	return *(s->top);
}
stack_t *stack_create(u32 m)
{
	stack_t *s = (stack_t *)kmalloc(sizeof(stack_t));
	s->max = m;
	s->base = (u32 *)kmalloc(m);
	s->top = s->base - 1;
	return s;
}
