typedef unsigned int u32;
typedef int s32;
typedef unsigned short u16;
typedef short s16;
typedef unsigned char u8;
typedef char s8;

#include "font.h"

struct pixel
{
	u8 blue;
	u8 green;
	u8 red;
} __attribute__((packed));

typedef struct pixel pixel_t;

typedef struct registers
{
	u32 ds;
	u32 edi, esi, ebp, esp, ebx, edx, ecx, eax;
	u32 int_no, err_code;
	u32 eip, cs, eflags, useresp, ss;
} registers_t;


void outb(u16 port, u8 value)
{
	asm volatile("outb %1, %0" : : "dN" (port), "a" (value));
}
 
u8 inb(u16 port)
{
	u8 ret;
	asm volatile("inb %1, %0" : "=a" (ret) : "dN" (port));
	return ret;
}

u16 inw(u16 port)
{
	u16 ret;
	asm volatile("inw %1, %0" : "=a" (ret) : "dN" (port));
	return ret;
}

void isr_handler(registers_t regs)
{
	unsigned char *videoram = (unsigned char *) 0xb8000;
	videoram[0] = 70;
	videoram[1] = 0x07;
}

pixel_t *videoram;
u32 width;
u32 height;

void monitor_init(pixel_t *vidstart)
{
	videoram = vidstart;
	width = 800;
	height = 600;
}

void plot_pixel(u32 x, u32 y, pixel_t px)
{
	pixel_t *p = videoram + (y*width + x);
	p->red = px.red;
	p->green = px.green;
	p->blue = px.blue;
}

void put_bmp(u8 *bmp, u32 w, u32 h, u32 x, u32 y, u8 r, u8 g, u8 b)
{
	u32 bit = 0;
	pixel_t px;
	while(bit < w*h)
	{
		u32 idx = bit / 8;
		u32 off = (8 - (bit % 8)) % 8;
		if(bmp[idx] & (1 << off))
		{
			px.red = r;
			px.green = g;
			px.blue = b;
		}
		else
		{
			px.red = 0;
			px.green = 0;
			px.blue = 0;
		}
		u32 x_off = bit % w;//(w - bit % w) % w;//to flip
		u32 y_off = bit / h;
		plot_pixel(x + x_off, y + y_off, px);
		bit++;
	}
}

void kmain(u32 vidstart)
{
	/* Write your kernel here. Example: 
	unsigned char *videoram = (unsigned char *) 0xb8000;
	videoram[0] = 88;
	videoram[1] = 0x06;*/
	u32 i = 0;
	/*for(i = 0; i < width; i++)
	{
		*(videoram + i) = 0xffffffff;
	}*/
	pixel_t px;
	px.red = px.green = 0x0;
	px.blue = 0xff;
	for(i = 0; i < 500; i++)
		plot_pixel(i,2*i,px);
	i = 0;
	put_bmp(fontA, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontB, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontC, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontD, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontE, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontF, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontG, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontH, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontI, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontJ, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontK, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontL, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontM, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontN, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontO, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontP, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontQ, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontR, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontS, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontT, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontU, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontV, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontW, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontX, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontY, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);
	put_bmp(fontZ, 8, 8, i = i+12, 3, 0xff, 0xff, 0xff);

	/*
	plot_pixel(50,50,px);
	plot_pixel(50,51,px);
	plot_pixel(50,52,px);
	plot_pixel(50,53,px);
	plot_pixel(50,54,px);
	plot_pixel(50,55,px);
	plot_pixel(51,55,px);
	plot_pixel(52,55,px);
	plot_pixel(53,55,px);
	plot_pixel(54,55,px);
	plot_pixel(55,55,px);
	//*/
	//videoram = 0;
}
