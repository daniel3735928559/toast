typedef unsigned int u32;
typedef int s32;
typedef unsigned short u16;
typedef short s16;
typedef unsigned char u8;
typedef char s8;

typedef struct registers
{
	u32 ds;
	u32 edi, esi, ebp, esp, ebx, edx, ecx, eax;
	u32 int_no, err_code;
	u32 eip, cs, eflags, useresp, ss;
} registers_t;


void outb(u16 port, u8 value)
{
	asm volatile("outb %1, %0" : : "dN" (port), "a" (value));
}
 
u8 inb(u16 port)
{
	u8 ret;
	asm volatile("inb %1, %0" : "=a" (ret) : "dN" (port));
	return ret;
}

u16 inw(u16 port)
{
	u16 ret;
	asm volatile("inw %1, %0" : "=a" (ret) : "dN" (port));
	return ret;
}


void isr_handler(registers_t regs)
{
	unsigned char *videoram = (unsigned char *) 0xb8000;
	videoram[0] = 70;
	videoram[1] = 0x07;
}

void kmain()
{
	/* Write your kernel here. Example: */
	unsigned char *videoram = (unsigned char *) 0xb8000;
	videoram[0] = 88;
	videoram[1] = 0x06;
}
