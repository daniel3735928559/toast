#define RD_SIZE 64
#define FN_SIZE 16
#define DIR_SIZE 32

/*
[format:]
rd_header_t;
rd_entry_t rd_entries[]
...data...
*/

typedef struct rd_entry
{
  char name[FN_SIZE];
  u8 is_dir;
  u32 size;
  void *start;
} rd_entry_t;

typedef struct rd_header
{
  u32 size;
  u32 num_files;
  rd_entry_t *root;
} rd_header_t;

rd_entry_t *rd_entries;
void *rd_data;

u32 rd_read(rd_entry_t *node, u8 offset, u32 size, u32 *buffer)
{
  if(offset + size >= node->size)
    return 1;
  //memcpy(rd_data + offset, buffer, size);
  return 0;
}

u32 rd_write(rd_entry_t *node, u8 offset, u32 size, u32 *buffer)
{
  return 0;
}
void rd_open(rd_entry_t *node, u8 read, u8 write)
{
  return;
}
void rd_close(rd_entry_t *node)
{
  return;
}
rd_entry_t *rd_readdir(rd_entry_t *node, u32 index)
{
  if((node->is_dir & 1) && index >= 0 && index < node->size){
    u32 *dirent_indices = (u32 *)(node->start);
    return &(rd_entries[dirent_indices[index]]);
  }
  
  return NULL;
}
rd_entry_t *rd_finddir(rd_entry_t *node, char *name)
{
  /*u32 i;
  for(i = 0; i < nentries; i++){
    rd_entry_t *next = rd_index + i*sizeof(rd_entry_t);
    u32 j = 0;
    while(next->name[j] == name[j])
      if(next->name[++j] == 0)
	return next;
  }*/
  return NULL;
}

void rd_init(void *ramdisk)
{
  rd_data = ramdisk;
  rd_header_t *header = (rd_header_t *)(rd_data);
}

