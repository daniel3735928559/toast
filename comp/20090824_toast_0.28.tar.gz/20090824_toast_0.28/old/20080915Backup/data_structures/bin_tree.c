typedef struct node
{
	u32 value;
	u32 level;
	s32 balance;
	struct node *parent;
	struct node *right;
	struct node *left;
} node_t;

typedef struct
{
	u32 node_count;
	node_t *root;
	void *start;
	void *end;
	u32 max;
} bin_tree_t;

//-1 = left rotation, 1 = right
void bin_tree_rotate(bin_tree_t *tree, node_t *base, u8 dir)
{
	node_t *pivot;
	if(dir > 0)
	{
		pivot = base->left;
		if(pivot == NULL){ return; }
		base->left = pivot->right;
		pivot->right = base;
	}
	else
	{
		pivot = base->right;
		if(pivot == NULL){ return; }
		base->right = pivot->left;
		pivot->left = base;
	}
	pivot->parent = base->parent;
	base->parent = pivot;
	if(base == tree->root);
		tree->root = pivot;
}

void rebalance(bin_tree_t *tree, node_t *start, u8 is_insert)
{
	if(start->parent != NULL)
	{
		node_t *par = start->parent;
		s8 bal = (par->left == start ? -1 : 1);
		par->balance += bal;
		
		if(par->balance > 1 || par->balance < -1)
		{
			node_t *heavy = (par->balance > 1 ? par->right : par->left);
			s8 sub_bal = (heavy->balance == bal ? bal : -bal);
			if(sub_bal != bal) bin_tree_rotate(tree, heavy, -sub_bal);
			bin_tree_rotate(tree, par, -bal);
		}
		else if(!is_insert && (par->balance == 1 || par->balance == -1))
			return;
		rebalance(tree, par, is_insert);
	}
}

node_t *bin_tree_put_leaf(bin_tree_t *tree, node_t *at, u32 val)
{
	tree->node_count++;
	tree->end += sizeof(node_t);
	node_t *new_node = (node_t *)(tree->end);
	new_node->value = val;
	new_node->parent = at;
	new_node->right = NULL;
	new_node->left = NULL;
	new_node->balance = 0;
	new_node->level = at->level + 1;
	if(val < at->value)
	{
		at->left = new_node;
		at->balance--;
	}
	else
	{
		at->right = new_node;
		at->balance++;
	}
	return new_node;
}

void bin_tree_insert_helper(bin_tree_t *tree, node_t *at, u32 val)
{
	node_t *to = at->value < val ? at->right : at->left;
	if(to == NULL)
		bin_tree_put_leaf(tree, at, val);
		//rebalance(bin_tree_put_leaf(tree, at, val), 1);
	else
		bin_tree_insert_helper(tree, to, val);
}

void bin_tree_insert(bin_tree_t *tree, u32 val)
{
	bin_tree_insert_helper(tree, tree->root, val);
}

node_t *bin_tree_best_fit_lookup(node_t *node, u32 val)
{
	if(node == NULL)
		return NULL;
	if(node->value >= val)
	{
		node_t *ret = bin_tree_best_fit_lookup(node->left, val);
		return (ret != NULL ? ret : node);
	}
	else
	{
		return bin_tree_best_fit_lookup(node->right, val);
	}
}

node_t *bin_tree_exact_lookup(node_t *node, u32 val)
{
	if(node->value == val)
		return node;
	node_t *to = node->value < val ? node->left : node->right;
	return bin_tree_exact_lookup(to, val);
}

node_t *bin_tree_lookup(bin_tree_t *tree, u32 val, u8 best_fit)
{
	return (best_fit ? bin_tree_best_fit_lookup(tree->root, val) : bin_tree_exact_lookup(tree->root, val));
}

void bin_tree_remove(bin_tree_t *tree, node_t *to_remove)
{
	to_remove->value = 0;
	to_remove->level = 0;
	to_remove->balance = 0;
	if(to_remove->parent == NULL)
	{
		//to_remove is root...
	}
	if(to_remove == to_remove->parent->left)
		to_remove->parent->left = to_remove->left;
	else
		to_remove->parent->right = to_remove->right;

	to_remove->left = 0;
	to_remove->right = 0;
	to_remove->parent = 0;
	memmove(to_remove + 1, to_remove, (long)(tree->end) - (long)(to_remove + sizeof(node_t)));

	node_t *n = tree->root;
	while(n <= (node_t *)(tree->end))
	{
		if(n->left > to_remove) n->left -= 1;
		if(n->right > to_remove) n->left -= 1;
		if(n->parent > to_remove) n->left -= 1;
		n += 1;
	}
	tree->end -= sizeof(node_t);
}

bin_tree_t *bin_tree_create(u32 max_size, u32 root_val)
{
	bin_tree_t *b = malloc(sizeof(bin_tree_t));

	node_t *root = (node_t *)malloc(sizeof(node_t) * max_size);
	b->root = root;
	b->start = b->root;
	b->end = b->start;
	b->node_count = 1;
	b->max = max_size;

	//printf("%d, %d, %d\n", b->root, b->end, b->max);

	root->value = root_val;
	root->level = 0;
	root->balance = 0;
	root->parent = NULL;
	root->left = NULL;
	root->right = NULL;
	
	return b;
}

void bin_tree_debug_print(bin_tree_t *b)
{
	node_t *n = b->start;
	while(n <= (node_t *)b->end)
	{
		printf("n @ %d : value=%d, level=%d, bal=%d, parent @ %d, left @ %d, right @ %d\n", n, n->value, n->level, n->balance, n->parent, n->left, n->right);
		n += 1;
	}
}

void bin_tree_print_helper(node_t *n)
{
	printf("L[");
	if(n->left != NULL) bin_tree_print_helper(n->left);
	printf("]");

	printf(" %d ", n->value);

	printf("R[");
	if(n->right != NULL) bin_tree_print_helper(n->right);
	printf("]");
}

void bin_tree_print(bin_tree_t *b)
{
	bin_tree_debug_print(b);
	bin_tree_print_helper(b->root);
	printf("\n");
}
