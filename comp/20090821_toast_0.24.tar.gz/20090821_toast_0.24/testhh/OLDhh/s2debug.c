char *cursor = (char *)0xb8000;

void putch(char c)
{
  if(c == '\n'){
    cursor = (char *)((int)cursor + 80*2);
    cursor = (char *)((int)cursor % 80*2);
  }
  else if(c == '\r')
    cursor = (char *)((int)cursor % 80);
  else if(c >= 32){
    *cursor = c;
    cursor += 2;
  }
}

void ph(u32 x)
{
  char output[8];
  int i, len = 0;
  for(i = 0; i < 8; i++){
    int d = x & 0x0f;
    if(d)
      len = i;
    if(d > 9)
      output[7 - i] = (55 + d);
    else
      output[7 - i] = (48 + d);
    x = x >> 4;
  }
  for(i = 7-len; i < 8; i++)
    putch(output[i]);
}

void prints(char *s)
{
  int i = 0;
  while(s[i])
    putch(s[i++]);
}

void debug_print(pagedir_t *dir)
{
  u32 i = 0;
  prints("\ndir");ph((u32)dir);
  prints("\ndir->physical_address: ");ph((u32)(dir->physical_address));
  for(i = 0; i < 1024; i++){
    if(dir->tables[i]){
      prints("\ntables[");ph(i);prints("]: ");ph((u32)(dir->tables[i]));
      int j = 0;
      for(j = 0; j < 1024; j++){
	if((dir->tables[i])->pages[j].frame){
	  prints("\npages[");ph(j);prints("]: ");ph((u32)(dir->tables[i]->pages[j].frame));
	}
      }
    }
  }
}
