#define BASE 0xA000

#define K_START 0xC1000000
#define K_START_PHYS 0x10000
#define K_SIZE 0x8000

#define STACK_TOP 0xC0002000
#define STACK_BASE 0xC0002000
#define STACK_TOP_PHYS 0x90000
#define STACK_BASE_PHYS 0x8F000

#define RD_START_PHYS 0x60000
#define RD_SIZE 0x2000
#define RD_START K_START-RD_SIZE

#define u32 int

typedef struct
{
  u32 present:1;
  u32 rw:1;
  u32 user:1;
  u32 accessed:1;
  u32 dirty:1;
  u32 unused:7;
  u32 frame:20;
} page_t;

typedef struct
{
  page_t pages[1024];
} page_table_t;

typedef struct
{
  page_table_t *tables[1024];
  u32 table_phys_addresses[1024];
  u32 physical_address;
} pagedir_t;

pagedir_t *kernel_dir;

#include "s2debug.c"

void clear_mem(u32 *start, u32 size)
{
  u32 *off = start;
  while((u32)off - (u32)start < size){
    *(off++) = 0;
  }
}

//CHECK THIS!!!!!!!

void map_to(pagedir_t *dir, void *start, u32 size, void *target)
{
  void *i;
  for(i = 0; (u32)i < size; i += 0x1000){
    u32 address = ((u32)start) / 0x1000;
    u32 table_index = address / 1024;
    u32 entry_index = address % 1024;
    page_table_t *table = (page_table_t *)(dir->table_phys_addresses[table_index]);
    if(table){
      page_t page = table->pages[entry_index];
      page.present = 1;
      page.rw = 1;
      page.user = 0;
      page.frame = (u32)(start + (u32)i) >> 12;
    }
  }
}

void paging_init(u32 vidmem)
{
  pagedir_t *pd = (pagedir_t *)0x91000;
  pd->physical_address = 0x91000;
  clear_mem((u32 *)pd, sizeof(pagedir_t));
  page_table_t *pt[4];
  u32 pt_bases[4] = {0x0, 0xC0000000, 0xC1000000, 0xF8000000};
  u32 i;
  for(i = 0; i < 4; i++){
    pt[i] = (page_table_t *)((u32)pd + sizeof(pagedir_t) + i*sizeof(page_table_t));
    clear_mem((u32 *)pt[i], sizeof(page_table_t));
    u32 idx = pt_bases[i] >> 24;
    pd->table_phys_addresses[idx] = (u32)pt[i];
    pd->tables[idx] = pt[i] + sizeof(pagedir_t) + (0xC0002000 - 0x91000);
  }

  //Fill Page Tables: 

  map_to(pd, 0, 256*0x1000, 0);
  map_to(pd, (void *)STACK_BASE_PHYS, STACK_TOP_PHYS - STACK_BASE_PHYS, (void *)STACK_BASE);
  map_to(pd, (void *)RD_START_PHYS, RD_SIZE, (void *)RD_START);
  map_to(pd, (void *)K_START_PHYS, K_SIZE, (void *)K_START);
  map_to(pd, (void *)vidmem, 800*600*3/4, (void *)vidmem);

  void *current_end = (void *)STACK_TOP;
  map_to(pd, pd, sizeof(pagedir_t), current_end);
  current_end += sizeof(pagedir_t);
  for(i = 0; i < 4; i++){
    map_to(pd, pt[i], sizeof(page_table_t), current_end);
    current_end += sizeof(page_table_t);
  }
}
