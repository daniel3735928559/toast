/*
[format:]
rd_header_t;
rd_entry_t rd_entries[]
...data...
*/

typedef struct rd_entry
{
  char name[FN_SIZE];
  u8 is_dir;
  u32 size;
  void *start;
} rd_entry_t;

typedef struct rd_dir
{
  u32 files;
  rd_entry_t *contents[DIR_SIZE];
} rd_dir_t;

typedef struct rd_header
{
  u32 size;
  u32 num_files;
  rd_entry_t *root;
} rd_header_t;

rd_entry_t *rd_entries;
fs_node_t *vfs_entries;
void *rd_data;

u32 rd_read(fs_node_t *node, u8 offset, u32 size, u32 *buffer)
{
  if(offset + size > node->length)
    return 1;
  memcpy(rd_data + offset, buffer, size);
  return 0;
}

u32 rd_write(fs_node_t *node, u8 offset, u32 size, u32 *buffer)
{
  return 0;
}
void rd_open(fs_node_t *node, u8 read, u8 write)
{
  return;
}
void rd_close(fs_node_t *node)
{
  return;
}
fs_node_t *rd_readdir(fs_node_t *node, u32 index)
{
  if((node->flags & 1) && index >= 0 && index < DIR_SIZE){
    rd_dir_t *dir = (rd_dir_t *)(node->start);
    return dir->contents[index];
  }
  
  return NULL;
}
fs_node_t *rd_finddir(fs_node_t *node, char *name)
{
  u32 i;
  for(i = 0; i < nentries; i++)
    {
      rd_entry_t *next = rd_index + i*sizeof(rd_entry_t);
      u32 j = 0;
      while(next->name[j] == name[j])
	if(next->name[++j] == 0)
	  return next;
    }
  return NULL;
}

void fs_build(rd_entry_t *root, fs_node_t *dest)
{
  u32 i;
  for(i = 0; i < FN_SIZE; i++)
    (dest->name)[i] = (root->name)[i];

  //dest->name = root->name;
  dest->flags = (root->is_dir ? 1 : 0);
  dest->inode = 0;
  dest->length = root->size;
  dest->read = rd_read;
  dest->write = rd_write;
  dest->open = rd_open;
  dest->close = rd_close;
  dest->readdir = rd_readdir;
  dest->finddir = rd_finddir;
  dest->ptr = 0;
  if(root->is_dir){
    u32 i;
    for(i = 0; i < DIR_SIZE; i++){
      rd_entry_t *file = rd_readdir(root, i);
      if(file != NULL){
	fs_build(file, (fs_node_t *)(kmalloc(sizeof(fs_node_t))));
	//Possibly change the malloc to a `next-free-index-from-array' thing later
      }
    }
  }
}

void rd_init(void *ramdisk)
{
  rd_data = ramdisk;
  rd_header_t *header = (rd_header_t *)(rd_data);
  
  rd_root->name = "/";
  rd_root->flags = 1;
  rd_root->inode = 0;
  rd_root->length = rd_header_t->root;
  rd_root->read = rd_read;
  rd_root->write = rd_write;
  rd_root->open = rd_open;
  rd_root->close = rd_close;
  rd_root->readdir = rd_readdir;
  rd_root->finddir = rd_finddir;
  rd_root->ptr = 0;
  
  
  
  fs_node *files[header->file_count];
  rd_root = header->root_dir;
  files[0] = rd_root;
  
  u32 n = *((u32 *)ramdisk);
  rd_index = malloc(n*sizeof(rd_entry_t));
  u32 i;
  u32 offset = sizeof(int);
  for(i = 0; i < n; i++)
    {
      rd_entry next = *(rd_index + i*sizeof(rd_entry));
      strcpy(next->name, ramdisk+offset, FN_SIZE);
      offset += FN_SIZE;
      next->start = *(ramdisk+offset);
      offset += sizeof(u32);
      next->size = *(ramdisk+offset);
      offset += sizeof(u32);
    }
  rd_data = ramdisk + offset;
  nentries = n;
}

