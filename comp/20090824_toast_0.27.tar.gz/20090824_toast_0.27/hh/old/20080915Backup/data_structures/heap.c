typedef struct
{
	*u32 start;
	u32 size;
} hole_t;

typedef struct
{
	u32 magic;
	u32 length;
	*block_footer_t footer;
} block_header_t;

typedef struct
{
	*block_header_t header;
	u32 magic;
} block_footer_t;

typedef struct
{
	*u32 start;
	u32 size;
	*olist index;
} heap_t;

heap_t kheap;

void heap_create(u32 initSize)
{
	kheap = malloc(sizeof(heap_t));
	*kheap->start = malloc(INIT_HEAP_SIZE);
	*kheap->size = INIT_HEAP_SIZE;
	*kheap->blocks = malloc(INDEX_SIZE * sizeof(block_t));
	*kheap->sizeList = malloc(INDEX_SIZE * sizeof(u32));
	(*kheap->blocks)->sizeListEntry = sizeList;
	(*kheap->blocks)->start = *kheap->start;
	(*kheap->blocks)->length = INIT_HEAP_SIZE;
}

void *get_first_fit(*heap_t heap, u32 size)
{
	u32 i = 0;
	while(((block_header_t*)olist_get(heap->index, i))->length < size && ((block_header_t*)olist_get(heap->index, i))->magic == HEAP_FREE){ i++; }
	return (i >= (*heap->sizeList)->length) ? -1 : i);
}

void *heapAlloc(*heap_t heap, u32 s)
{
	u32 size = s + sizeof(block_header_t) + sizeof(block_footer_t);
	u32 i = get_first_fit(heap, size);
	hole_t *old_hole = *(olist_get(&heap->index, i)));
	block_header_t *annexee = &(old_hole->start);
	
	u32 hole_size = old_hole->size;
	u32 *hole_start = old_hole->start;
	olist_remove(heap->index, i);
	
	block_footer_t annexee_foot = *(annexee + sizeof(block_header_t) + s);
	annexee_foot->magic = HEAP_OCCUPIED;
	annexee_foot->header = annexee;h
	annexee->magic = HEAP_OCCUPIED;
	annexee->footer = annexee_foot;
	annexee->length = s;
	
	if(size < *old_hole->size)
	{
		hole_t *new_hole = olist_insert(*heap->index, *annexee->size - s);
		new_hole->start = *(annexee_foot+sizeof(block_footer_t));
		*(new_hole->start) = HEAP_FREE;
	}
}

void heapFree(*heap_t heap, u32 start)
{
	*block_header_t free_header = *(start - sizeof(block_header_t));
	*free_header->magic = HEAP_FREE;
	(block_footer_t*)(*free_header->footer)->magic = HEAP_FREE;
	if(*(free_header->))
	{
		
	}
}

void heap_debug_print(*heap_t heap)
{
	
}