heap_t *kheap;

void heap_init()
{
	kheap = heap_create(INIT_HEAP_SIZE);	
}

