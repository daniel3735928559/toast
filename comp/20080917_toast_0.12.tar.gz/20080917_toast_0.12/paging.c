typedef struct
{
	u32 present:1;
	u32 rw:1;
	u32 user:1;
	u32 accessed:1;
	u32 dirty:1;
	u32 unused:7;
	u32 frame:20;
} page_t;

typedef struct
{
	page_t pages[1024];
} page_table_t;

typedef struct
{
	page_table_t *tables[1024];
	u32 table_phys_addresses[1024];
	u32 physical_address;
} pagedir_t;

imap_t *frames_map;
pagedir_t *kernel_dir;
pagedir_t *current_dir;

void get_frame(page_t *page, u8 mode, u8 rw)
{
	if(page->frame != 0)
	{
		return;
	}
	else
	{
		u32 i = imap_set_next(frames_map);
		if(i == -1)
		{
			return;
		}
		page->present = 1;
		page->rw = rw?1:0;
		page->user = mode?1:0;
		page->frame = i;
	}
}

void release_frame(page_t *page)
{
	if(!(page->frame))
	{
		return;
	}
	else
	{
		imap_clear(frames_map, page->frame);
		page->frame = 0;
	}
}

void switch_pagedir(pagedir_t *dir)
{
	current_dir = dir;
	asm volatile("mov %0, %%cr3":: "r"(&dir->table_phys_addresses));
	u32 cr0;
	asm volatile("mov %%cr0, %0": "=r"(cr0));
	cr0 |= 0x80000000; // Enable paging!
	asm volatile("mov %0, %%cr0":: "r"(cr0));
}

page_t *get_page(u32 address, u8 make, pagedir_t *dir)
{
	address /= 0x1000;
	u32 table_index = address / 1024;
	if (dir->tables[table_index])
	{
		return &dir->tables[table_index]->pages[address%1024];
	}
	else if(make)
	{
		u32 tmp;
		dir->tables[table_index] = (page_table_t*)kmalloc_ap(sizeof(page_table_t), &tmp);
		setm((u32 *)dir->tables[table_index], 0, 0x1000);
		dir->table_phys_addresses[table_index] = tmp | 0x7;
		return &dir->tables[table_index]->pages[address%1024];
	}
	else
	{
		return 0;
	}
}

void paging_init()
{
	u32 mem_size = 0x10000000;	
	u32 num_frames = mem_size/0x1000;
	frames_map = imap_create(num_frames);
	setm((u32 *)(frames_map->bitmap->bits), 0, num_frames);
	//memset((u8 *)(frames_map->bitmap->bits), 0, num_frames);
	
	kernel_dir = (pagedir_t *)kmalloc_a(sizeof(pagedir_t));
	setm((u32 *)kernel_dir, 0, sizeof(pagedir_t));
	current_dir = kernel_dir;

	print_hex_32((u32)kernel_dir);prints("! ");
	print_hex_32((u32)frames_map);prints("! ");
	print_hex_32(EOK);prints("! ");
	/*u32 i = 0;
	bitmap_print(frames_map->bitmap);
	prints("!!!!\n\n");
	while(i < mem_size)
	{
		get_frame(get_page(i, 1, kernel_dir), 0, 0);
		i += 0x1000;
	}
	bitmap_print(frames_map->bitmap);
	prints("!!!!!!\n\n");*/

	
	u32 i;	
	for(i = (u32)videoram; i < ((u32)videoram) + height*width*3; i += 0x1000)
	{
		page_t *p = get_page(i, 1, kernel_dir);
		p->frame = i/0x1000;
		p->present = 1;
		p->rw = 0;
		p->user = 1;
	}
	for(i = 0; i <= 0x10*EOK; i+= 0x1000)
	{
		page_t *p = get_page(i, 1, kernel_dir);
		//print_hex_32(i);prints(": ");print_hex_32((u32)p);prints("? ");
		p->frame = i/0x1000;
		p->present = 1;
		p->rw = 0;
		p->user = 1;
	}
	newline();
	print_hex_32(EOK);prints("! ");
	print_hex_32((u32)videoram);prints("! ");
	prints("ENTERING PAGED WORLD...\n");
	newline();
	for(i = 0; i <= (EOK / 0x1000); i++)
	{
		u32 tab = i/1024;
		u32 pag = i % 1024;
		prints("t=");print_hex_32(tab);prints(", p=");print_hex_32(pag);prints(": ");
		print_hex_32(kernel_dir->table_phys_addresses[tab]); 
		prints("=");
		print_hex_32((u32)(kernel_dir->tables[tab])); 
		prints(" ");
		print_hex_32( ((page_table_t *)((kernel_dir->table_phys_addresses[tab]) - 7)) -> pages[pag].frame);
		prints("=");
		print_hex_32(kernel_dir->tables[tab]->pages[pag].frame);
		prints("=");
		print_hex_32(*((u32 *)(&(kernel_dir->tables[tab]->pages[pag]))));
		prints("; ");
		//print_hex_32(kernel_dir->tables[0]->pages[i].frame);prints("! ");
	}
	/*for(i = 0; i < 1024; i++)
	{
		print_hex_32(kernel_dir->tables[0]->pages[i].frame);prints("! ");
	}*/
	switch_pagedir(kernel_dir);
	/*prints("HELLO PAGED WORLD...\n");
	prints("HELLO PAGED WORLD...\n");
	prints("HELLO PAGED WORLD...\n");
	prints("HELLO PAGED WORLD...\n");
	prints("HELLO PAGED WORLD...\n");
	prints("HELLO PAGED WORLD...\n");
	prints("HELLO PAGED WORLD...\n");
	prints("HELLO PAGED WORLD...\n");
	prints("HELLO PAGED WORLD...\n");
	prints("HELLO PAGED WORLD...\n");
	prints("HELLO PAGED WORLD...\n");
	putch('*');
	putch('*');
	putch('*');*/
}
