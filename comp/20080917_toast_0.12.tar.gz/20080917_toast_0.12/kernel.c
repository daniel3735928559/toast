#include "stuff.h"
#include "datastr.c"
#include "monitor.c"
#include "paging.c"

void isr_handler(registers_t regs)
{
	/*pixel_t px;
	px.red = px.blue = 0x0;
	px.green = 0xff;
	plot_pixel(100,100,px);*/
}

void test_print()
{
	putch('A');
	putch('B');
	char c;
	for(c = ' '; c < 100; c++)
		putch(c);
	newline();
	putch('Y');
	putch('Z');
	newline();
	print_hex_32(0x12AB34CD);
	newline();
	print_dec_32(12345);
	newline();
	putch(33);
	putch(34);
	putch(' ');
	putch(']');
	putch(']'-1);
	putch(']'+1);
	newline();
	print_dec_32((u32)']');
	newline();
	prints("Hello World!");
	newline();
}

void kmain(u32 vidstart)
{
	/*print_dec_32(EOK); prints(", "); print_hex_32(EOK);
	print_hex_32(0xABACDC00);
	newline();
	print_hex_32(0x00BBBB00);
	newline();
	print_hex_32(0x0);
	newline();
	print_hex_32(0x012340);*/
	paging_init();
	prints("HELLO PAGED WORLD...\n");
	/*pixel_t px;
	px.red = 0xff;
	px.blue = px.green = 0;
	print_dec_32(EOK); prints(", "); print_hex_32(EOK);
	newline();
	print_bin_32(1293); prints(", "); print_bin_32(127); prints(", "); print_bin_32(929);
	putch('\n');
	print_dec_32((u32)videoram); prints(", "); print_hex_32((u32)videoram);
	newline();
	u32 j = 0;
	for(j = 0; j < 40; j++)
	{
		u32 pag = kernel_dir->tables[32]->pages[j].frame;
		print_hex_32(pag);prints(" ");
	}
	*videoram = px;*/
}
