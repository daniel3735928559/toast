#define RD_SIZE 64
#define FN_SIZE 16
#define DIR_SIZE 32

typedef u32 (*read_type_t)(struct fs_node*,u32,u32,u8*);
typedef u32 (*write_type_t)(struct fs_node*,u32,u32,u8*);
typedef void (*open_type_t)(struct fs_node*);
typedef void (*close_type_t)(struct fs_node*);
typedef struct dirent * (*readdir_type_t)(struct fs_node*,u32);
typedef struct fs_node * (*finddir_type_t)(struct fs_node*,char *name);

typedef struct fs_node
{
  char name[FN_SIZE];
  u32 flags;
  u32 inode;
  u32 length;
  read_type_t read;
  write_type_t write;
  open_type_t open;
  close_type_t close;
  readdir_type_t readdir;
  finddir_type_t finddir;
} fs_node_t;


struct dirent
{
  char name[128];
  u32 ino;
};

fs_node_t *fs_root = 0;

u32 read_fs(fs_node_t *node, u32 offset, u32 size, u8 *buffer)
{
  if (node->read != 0)
    return node->read(node, offset, size, buffer);
  else
    return 0;
}
void open_fs(fs_node_t *node, u8 read, u8 write)
{
  if (node->open != 0)
    return node->open(node);
  else
    return 0;
}
void close_fs(fs_node_t *node)
{
  if (node->close != 0)
    return node->close(node);
  else
    return 0;
}
u32 write_fs(fs_node_t *node, u8 offset, u32 size, u8 *buffer)
{
  if (node->write != 0)
    return node->write(node, offset, size, buffer);
  else
    return 0;
}
dirent *readdir_fs(fs_node_t *node, u32 index)
{
  if (node->readdir != 0 && node->flags & (1 << 1))
    return node->readdir(node, index);
  else
    return 0;
}
fs_node_t *finddir_fs(fs_node_t *node, char *name)
{
  if (node->finddir != 0 && node->flags & (1 << 1))
    return node->finddir(node, name);
  else
		return 0;
}
