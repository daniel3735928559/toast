#define K_BASE_PHYS 0x10000
#define K_DATA_PHYS 0x30000
#define K_DATA_SIZE 0x400000
#define K_STACK_PHYS 0x80000
#define K_STACK_SIZE 0x10000
#define K_SIZE 0x400000
#define STACK_BASE 0x90000
#define STACK_SIZE 0x4000

typedef struct
{
  u32 present:1;
  u32 rw:1;
  u32 user:1;
  u32 accessed:1;
  u32 dirty:1;
  u32 unused:7;
  u32 frame:20;
} page_t;

typedef struct
{
  page_t pages[1024];
} page_table_t;

typedef struct
{
  page_table_t *tables[1024];
  u32 table_phys_addresses[1024];
  u32 physical_address;
} pagedir_t;

imap_t *frames_map;
pagedir_t *kernel_dir;
pagedir_t *current_dir;

void get_a_frame(page_t *page, u8 mode, u8 rw)
{
  if(page->frame != 0){
    return;
  }
  else{
    u32 i = imap_set_next(frames_map);
    if(i == -1){
      return;
    }
    page->present = 1;
    page->rw = rw?1:0;
    page->user = mode?1:0;
    page->frame = i;
  }
}

void get_specific_frame(page_t *page, u32 frame_addr, u8 mode, u8 rw)
{
  if(page->frame != 0)
    return;
  else{
    bitmap_set(frames_map->bitmap, (frame_addr >> 12));
    page->present = 1;
    page->rw = rw?1:0;
    page->user = mode?1:0;
    page->frame = (frame_addr >> 12);
  }
}

void release_frame(page_t *page)
{
  if(!(page->frame)){
    return;
  }
  else{
    imap_clear(frames_map, page->frame);
    page->frame = 0;
  }
}

void switch_pagedir(pagedir_t *dir)
{
  current_dir = dir;
  asm volatile("mov %0, %%cr3":: "r"(dir->physical_address));
  asm("hlt");
  u32 cr0;
  asm volatile("mov %%cr0, %0": "=r"(cr0));
  cr0 |= 0x80000000; // Enable paging!
  asm volatile("mov %0, %%cr0":: "r"(cr0));
}

page_t *get_page(u32 address, u8 make, pagedir_t *dir)
{
  address /= 0x1000;
  u32 table_index = address / 1024;
  if (dir->tables[table_index]){
    return &dir->tables[table_index]->pages[address%1024];
  }
  else if(make){
    u32 tmp;
    dir->tables[table_index] = (page_table_t*)kmalloc_ap(sizeof(page_table_t), &tmp);
    setm((u32 *)dir->tables[table_index], 0, 0x1000);
    //print_hex_32(table_index);prints(": ");print_hex_32(tmp);prints("! ");

    dir->table_phys_addresses[table_index] = tmp | 0x7;
    return &dir->tables[table_index]->pages[address%1024];
  }
  else{
      return 0;
  }
}

void paging_idmap(void *start, u32 size, u8 mode, u8 rw)
{
  void *i;
  for(i = start; i < start + size; i += 0x1000)
    get_specific_frame(get_page((u32)i, 1, kernel_dir), (u32)i, mode, rw);
}

void paging_mapto(void *start, u32 size, void *target, u8 mode, u8 rw)
{
  void *i;
  for(i = 0; (u32)i < size; i += 0x1000)
    get_specific_frame(get_page((u32)(target + (u32)i), 1, kernel_dir), (u32)(start + (u32)i), mode, rw);
}

void paging_debug_print()
{
  u32 i;
  for(i = 0; i <= (EOK / 0x10); i++){
    u32 tab = i/1024;
    u32 pag = i % 1024;
    prints("T=");print_hex_32(tab);prints(", P=");print_hex_32(pag);prints(": ");
    print_hex_32(kernel_dir->table_phys_addresses[tab]); 
    prints("=");
    print_hex_32((u32)(kernel_dir->tables[tab])); 
    prints(" ");
    print_hex_32( ((page_table_t *)((kernel_dir->table_phys_addresses[tab]) - 7)) -> pages[pag].frame);
    prints("=");
    print_hex_32(kernel_dir->tables[tab]->pages[pag].frame);
    prints("=");
    print_hex_32(*((u32 *)(&(kernel_dir->tables[tab]->pages[pag]))));
    prints("; ");
    //print_hex_32(kernel_dir->tables[0]->pages[i].frame);prints("! ");
  }
  /*for(i = 0; i < 1024; i++)
    {
    print_hex_32(kernel_dir->tables[0]->pages[i].frame);prints("! ");
    }*/
}

void paging_init()
{
  u32 mem_size = 0x10000000;	
  u32 num_frames = mem_size/0x1000;
  frames_map = imap_create(num_frames);
  setm((u32 *)(frames_map->bitmap->bits), num_frames, 0);
  
  kernel_dir = (pagedir_t *)kmalloc_a(sizeof(pagedir_t));

  setm((u32 *)kernel_dir, sizeof(pagedir_t), 0);
  //Set the kernel dir's physical address by taking its virtual address (which we have now) and subtracting the offset we know has been applied: 
  kernel_dir->physical_address = (u32)(kernel_dir->table_phys_addresses) - phys_offset;
  current_dir = kernel_dir;
  //paging_debug_print();

  paging_mapto((void *)K_BASE_PHYS, K_SIZE, (void *)0xC0000000, 1, 0);
  paging_mapto((void *)K_DATA_PHYS, K_DATA_SIZE, (void *)0xC1000000, 1, 0);
  paging_idmap((void *)K_STACK_PHYS, K_STACK_SIZE, 1, 0);
  paging_idmap((void *)(videoram), height*width*3, 1, 0);

  imap_stack_reset(frames_map);
  prints("\n\n");
  print_hex_32((u32)(kernel_dir->table_phys_addresses[0x300]));
  //asm("hlt");
  switch_pagedir(kernel_dir);
}
