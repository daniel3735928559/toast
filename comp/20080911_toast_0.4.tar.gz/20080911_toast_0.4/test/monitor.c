#include "font.h"

struct pixel
{
	u8 blue;
	u8 green;
	u8 red;
} __attribute__((packed));

typedef struct pixel pixel_t;

pixel_t *videoram;
u32 width;
u32 height;

void monitor_init(pixel_t *vidstart)
{
	videoram = vidstart;
	width = 800;
	height = 600;
}

void plot_pixel(u32 x, u32 y, pixel_t px)
{
	pixel_t *p = videoram + (y*width + x);
	p->red = px.red;
	p->green = px.green;
	p->blue = px.blue;
}

void put_bmp(u8 *bmp, u32 w, u32 h, u32 x, u32 y, u8 r, u8 g, u8 b)
{
	u32 bit = 0;
	pixel_t px;
	while(bit < w*h)
	{
		u32 idx = bit / 8;
		u32 off = (8 - (bit % 8)) % 8;
		if(bmp[idx] & (1 << off))
		{
			px.red = r;
			px.green = g;
			px.blue = b;
		}
		else
		{
			px.red = 0;
			px.green = 0;
			px.blue = 0;
		}
		u32 x_off = bit % w;//(w - bit % w) % w;//to flip
		u32 y_off = bit / h;
		plot_pixel(x + x_off, y + y_off, px);
		bit++;
	}
}

void cls()
{
	pixel_t *px = videoram;
	while(px < videoram + width * height)
	{
		px->red = px->green = px->blue = 0x00000000;
		px += 1;
	}
}
