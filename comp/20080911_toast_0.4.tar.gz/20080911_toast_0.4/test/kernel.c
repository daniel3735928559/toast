#include "stuff.h"
#include "monitor.c"
#include "paging.c"

void isr_handler(registers_t regs)
{
	pixel_t px;
	px.red = px.blue = 0x0;
	px.green = 0xff;
	plot_pixel(100,100,px);
}

void kmain(u32 vidstart)
{
	u32 i = 0;
	pixel_t px;
	px.red = px.green = 0x0;
	px.blue = 0xff;
	for(i = 0; i < 500; i++)
		plot_pixel(i,2*i,px);
	//cls();
	u32 j = 0;
	for(i = 0; i < 111; i++)
		put_bmp(font[i], fwidth, fheight, j = j + 8, 3, 0xff, 0xff, 0xff);
}
