typedef struct pageTableEntry
{
	u32int present:1;
	u32int rw:1;
	u32int user:1;
	u32int rsvd1:2;
	u32int accessed:1;
	u32int dirty:1;
	u32int rsvd2:2;
	u32int spec:3;
	u32int frame:20;
} page;

typedef struct pageTable
{
	page pages[1024];
} table;

typedef struct pageDirectory
{
	table tables[1024];
	u32int physTables[1024];
	u32int physicalAddress;
} dir;

(~x)&((~x)+1)