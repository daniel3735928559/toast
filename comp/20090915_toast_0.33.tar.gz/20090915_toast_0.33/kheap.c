#define KHEAP_HEAP_SLAB_SIZE 0x1000
#define MAX_KHEAPS 0x100000
#define KHEAP_INIT_SIZE 0x4000
#define KHEAP_START 0xC1000000

typedef struct kheap{
  u32 block_size;
  u32 slab_size;
  u32 max_size;
  stack_t free_stack;
  u32 next_free;
  void (*constructor)(void *);
  void (*destructor)(void *);
  void *start;
  void *top;
} kheap_t;

kheap_t *kheap_heap;

void kheap_heap_init()
{
  kheap_heap = kmalloc(sizeof(kheap_t));
  kheap_init(kheap_heap, sizeof(heap_t), KHEAP_HEAP_SLAB_SIZE, MAX_KHEAPS, KHEAP_INIT_SIZE, zero, zero, KHEAP_START);
}

kheap_t *kheap_init(kheap_t *heap, u32 b_size, u32 s_size, u32 m_size, u32 init_slabs, void *constr(), void *destr(), void *location)
{
  heap->block_size = b_size;
  heap->spab_size = s_size;
  heap->max_size = m_size;
  heap->constructor = constr;
  heap->destructor = destr;
  heap->free_block;
  heap->next_free = 0;
  heap->start = location;
  kheap_expand(heap, init_slabs);
  return heap;
}

kheap_t *kheap_create()
{
  return (kheap_t *)(heap_alloc(kheap_heap));
}

void *kheap_alloc(kheap_t *heap)
{
  if((heap->free_stack)->top == (heap->free_stack)->base - 1) return kheap_get_block(heap, (heap->next_free)++);
  return kheap_get_block(heap, stack_pop(heap->free_stack));
}

void kheap_free(kheap_t *heap, void *block)
{
  u32 idx = kheap_get_index(heap, block);
  if(idx == (heap->next_free) - 1) next_free--;
  else stack_push(heap->free_stack, idx);
}

u32 kheap_get_index(kheap_t *heap, void *block_addr)
{
  return ((u32)block_addr - (u32)(heap->start))/(heap->block_size);
}

void *kheap_get_block(kheap_t *heap, u32 index)
{
  return (void *)((u32)(heap->start) + index*((u32)(heap->block_size)));
}

u32 kheap_expand(kheap_t *heap, u32 slabs)
{
  if((u32)(heap->top) - (u32)(heap->start) > m_size*block_size) return -1;
  
  u32 target = (heap->slab_size)*slabs + heap->top;
  while(heap->top <= target){
    ....
    heap->top += 0x1000;
  }
}

void kheap_contract(kheap_t *heap, u32 slabs)
{
  
}

void kheap_debug_print(kheap_t *heap)
{
  prints("Hello World!");
}
