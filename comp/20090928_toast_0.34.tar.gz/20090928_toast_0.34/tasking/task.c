kheap_t *stack_heap;
kheap_t *pagedir_heap;
kheap_t *node_heap;
kheap_t *pagetable_heap;

kheap_t *event_heap;
kheap_t *connection_heap;

u32 pid = 0;

typedef struct node
{
  u32 UID;
  u32 esp;
  u32 kesp;
  u32 ebp;
  u32 eip;
  pagedir_t *pagedir;
  node_t *next;
} node_t;

void tasking_init()
{
  stack_heap = kheap_init(kheap_alloc(kheap_heap), 0x2000, 0x2000, MAX_NODES, INIT_NODES, zero, zero);
  pagedir_heap = kheap_init(kheap_alloc(kheap_heap), 0x1000, 0x10000, MAX_NODES, INIT_NODES, fill_kernel_pagedirs, fill_kernel_pagedirs);
  node_heap = kheap_init(kheap_alloc(kheap_heap), sizeof(node_t), 0x10000, MAX_NODES, INIT_NODES, node_init, zero);
  pagetable_heap = kheap_init(kheap_alloc(kheap_heap), 0x1000, 0x10000, 0x300*MAX_NODES, 0x300*INIT_NODES, zero, zero);
}

node_t *node_init(void *place)
{
  node_t *new_node = (node_t *)(place);
  new_node->UID = pid++;
  new_node->kesp = heap_alloc(stack_heap);
  new_node->esp = USER_STACK;
  new_node->ebp = USER_STACK;
  new_node->pagedir = (pagedir_t *)(heap_alloc(pagedir_heap));
  return new_node;
}

node_t *make_node()
{
  node_t *new_node = (node_t *)(heap_alloc(node_heap, 1));
  return new_node;
}

void dump_node(node_t *to_dump)
{
  heap_free(to_dump);
}

void switch_task(node_t *new_task)
{
  current_node->eip = get_EIP();
  set_pagedir(new_task->pagedir);
  
}

extern get_EIP;

get_EIP: 
  pop eax;
  jmp eax;
